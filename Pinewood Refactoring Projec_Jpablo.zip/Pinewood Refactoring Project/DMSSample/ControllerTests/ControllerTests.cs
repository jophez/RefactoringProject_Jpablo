using Moq;
using Moq.Protected;
using Pinewood.DMSSample.Business;

namespace ControllerTests
{
    [TestClass]
    public class ControllerTests
    {
        [TestMethod]
        public void CustomerGetName_WhenNameParameterIsNotNull_ShouldReturnValidResult()
        {
            //Arrange
            string testName = "Fake Name";
            var mockRepository = new Mock<ICustomerRepositoryDb>();
            mockRepository.Setup(x => x.GetByName(It.IsAny<string>()))
                .Returns(new Customer() { ID = 999, Name = "Fake Name", Address = "Fake Address" });


            //Act
            var sut = new CustomerManager(mockRepository.Object);
            var result = sut.GetByName(testName);

            //Assert
            Assert.IsTrue(testName.Equals(result.Name));
            Assert.IsTrue(result != null);
        }

        [TestMethod]
        public void CustomerGetName_WhenNameParameterIsNull_ShouldReturnEmptyStringForNameField()
        {
            //Arrange
            string testName = "";
            var mockRepository = new Mock<ICustomerRepositoryDb>();
            mockRepository.Setup(x => x.GetByName(It.IsAny<string>()))
                .Returns(new Customer() { ID = 0, Name = String.Empty, Address = String.Empty });


            //Act
            var sut = new CustomerManager(mockRepository.Object);
            var result = sut.GetByName(testName);

            //Assert
            Assert.IsTrue(testName.Equals(result.Name));
            Assert.IsTrue(result.Name.Length == 0);
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void PartInvoiceAdd_WhenParametersAreInvalid_ShouldThrowAnException()
        {
            //Arrange
            var testData = new PartInvoice()
            {
                CustomerID = 0,
                Quantity = 0,
                StockCode = String.Empty
            };
            var mockRepository = new Mock<IPartInvoiceRepositoryDb>();
            mockRepository.Setup(x => x.Add(testData))
                .Throws(new ApplicationException());
            var sut = new PartInvoiceManager(mockRepository.Object);

            //Act
            sut.Add(testData);
        }

        [TestMethod]
        public void PartInvoiceAdd_WhenParametersAreValid_ShouldCreateNewRecord()
        {
            //Arrange
            var testData = new PartInvoice()
            {
                CustomerID = 1,
                Quantity = 10,
                StockCode = "1234"
            };
            var mockRepository = new Mock<IPartInvoiceRepositoryDb>();
            mockRepository.Setup(x => x.Add(testData));
            var sut = new PartInvoiceManager(mockRepository.Object);

            //Act
            sut.Add(testData);

            //Assert
            mockRepository.Verify(x => x.Add(testData), Times.Once);
        }

        [TestMethod]
        public void Controller_WhenParametersAreValid_ShouldCreateNewRecord()
        {
            //Arrange
            string testName = "Fake Name";
            var testData = new PartInvoice()
            {
                CustomerID = 1,
                Quantity = 10,
                StockCode = "1234"
            };
            var mockRepositoryCustomer = new Mock<ICustomerRepositoryDb>();
            mockRepositoryCustomer.Setup(x => x.GetByName(It.IsAny<string>()))
                .Returns(new Customer() { ID = 999, Name = "Fake Name", Address = "Fake Address" });

            var mockRepositoryPIInv = new Mock<IPartInvoiceRepositoryDb>();
            mockRepositoryPIInv.Setup(x => x.Add(testData));

            var mockHttpResult = new Mock<HttpMessageHandler>();
            mockHttpResult.Protected()
                .Setup<Task<HttpResponseMessage>>("SendAsync", ItExpr.IsAny<HttpRequestMessage>(), ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(new HttpResponseMessage { StatusCode = System.Net.HttpStatusCode.OK });

            var customerSUT = new CustomerManager(mockRepositoryCustomer.Object);
            var piInvoiceSUT = new PartInvoiceManager(mockRepositoryPIInv.Object);
            var client = new HttpClient(mockHttpResult.Object);

            var partAvaiSUT = new PartAvailabilityClient();
            //Act
            var resultCustomer = customerSUT.GetByName(testName);
            piInvoiceSUT.Add(testData);
            var resultPartAvail = partAvaiSUT.GetAvailability(testData.StockCode);

            //Assert
            mockRepositoryPIInv.Verify(x => x.Add(testData), Times.Once);
            Assert.IsTrue(resultCustomer.Name.Equals(testName));
            Assert.IsTrue(resultPartAvail != null);
            Assert.IsTrue(resultPartAvail.Id > 0);

        }
    }
}