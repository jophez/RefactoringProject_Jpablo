﻿namespace Pinewood.DMSSample.Business
{
    public class PartInvoice : BaseEntity
    {
        public string? StockCode { get; set; }
        public int Quantity { get; set; }
        public int CustomerID { get; set; }
    }
}
