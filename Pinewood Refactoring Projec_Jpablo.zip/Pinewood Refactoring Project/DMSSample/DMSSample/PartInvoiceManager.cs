﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pinewood.DMSSample.Business
{
    public class PartInvoiceManager : IPartInvoiceManager
    {
        IPartInvoiceRepositoryDb _partInvoiceRepositoryDb;
        public PartInvoiceManager(IPartInvoiceRepositoryDb partInvoiceRepositoryDb)
        {
            _partInvoiceRepositoryDb = partInvoiceRepositoryDb;
        }
        public void Add(PartInvoice partInvoice)
        {
           _partInvoiceRepositoryDb.Add(partInvoice);
        }
    }
}
