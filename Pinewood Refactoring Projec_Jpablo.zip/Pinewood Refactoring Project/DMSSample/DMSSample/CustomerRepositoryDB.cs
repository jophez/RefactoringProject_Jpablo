﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Pinewood.DMSSample.Business
{
    internal sealed class CustomerRepositoryDB : ICustomerRepositoryDb
    {
        public CustomerRepositoryDB()
        {
        }

        public Customer GetByName(string name)
        {
            string ConnectionStr = ConfigurationManager.ConnectionStrings["appDatabase"].ConnectionString;
            Customer _customer = new Customer();
            using (SqlConnection _connection = new SqlConnection(ConnectionStr))
            {
                using SqlCommand cmd = new("CRM_GetCustomerByName", _connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Name", SqlDbType.NVarChar).Value = name;

                _connection.Open();
                SqlDataReader _reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (_reader.Read())
                {
                    _customer = new Customer()
                    {
                        ID = (int)_reader["CustomerID"],
                        Name = (string)_reader["Name"],
                        Address = (string)_reader["Address"]
                    };
                }
            }

            return _customer;
        }
    }
}
