﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pinewood.DMSSample.Business
{
    public class CustomerManager : ICustomerManager
    {
        private readonly ICustomerRepositoryDb _customerRepositoryDb;

        public CustomerManager(ICustomerRepositoryDb customerRepositoryDb)
        {
            _customerRepositoryDb = customerRepositoryDb;
        }

        public Customer GetByName(string name)
        {
           return _customerRepositoryDb.GetByName(name);
        }
       
    }
}
