﻿using System.Configuration;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace Pinewood.DMSSample.Business
{
    public class PartInvoiceController
    {
        public PartInvoiceController()
        {

        }
        public async Task<CreatePartInvoiceResult> CreatePartInvoiceAsync(string stockCode, int quantity, string customerName)
        {
            try
            {
                var _customer = new CustomerManager(new CustomerRepositoryDB()).GetByName(customerName);

                if (string.IsNullOrEmpty(stockCode) || quantity < 1 || _customer.ID == 0)
                {
                    return new CreatePartInvoiceResult(false);
                }

                using (PartAvailabilityClient _partAvailabilityService = new PartAvailabilityClient())
                {
                    int _availability = await _partAvailabilityService.GetAvailability(stockCode);
                    if (_availability <= 0)
                    {
                        return new CreatePartInvoiceResult(false);
                    }
                }

                new PartInvoiceRepositoryDB().Add(new PartInvoice()
                {
                    CustomerID = _customer.ID,
                    Quantity = quantity,
                    StockCode = stockCode
                });
            }
            catch (Exception)
            {
                return new CreatePartInvoiceResult(false);
            }

            return new CreatePartInvoiceResult(true);
        }
    }
}
