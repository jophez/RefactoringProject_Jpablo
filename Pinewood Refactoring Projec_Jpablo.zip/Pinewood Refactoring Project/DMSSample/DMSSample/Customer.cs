﻿namespace Pinewood.DMSSample.Business
{
    public class Customer : BaseEntity
    {
        public Customer()
        {

        }
        public string? Name { get; set; }
        public string? Address { get; set; }
    }
}
