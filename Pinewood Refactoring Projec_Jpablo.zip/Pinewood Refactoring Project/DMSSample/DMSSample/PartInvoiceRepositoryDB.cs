﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Pinewood.DMSSample.Business
{
    internal sealed class PartInvoiceRepositoryDB : IPartInvoiceRepositoryDb
    {
        public PartInvoiceRepositoryDB()
        {
            
        }

        public void Add(PartInvoice invoice)
        {
           string ConnectionStr = ConfigurationManager.ConnectionStrings["appDatabase"].ConnectionString;
            using (SqlConnection _connection = new SqlConnection(ConnectionStr))
            {
                using SqlCommand _cmd = new("PMS_AddPartInvoice", _connection);
                _cmd.CommandType = CommandType.StoredProcedure;
                _cmd.Parameters.Add("@StockCode", SqlDbType.VarChar).Value = invoice.StockCode;
                _cmd.Parameters.Add("@Quantity", SqlDbType.Int).Value = invoice.Quantity;
                _cmd.Parameters.Add("@CustomerID", SqlDbType.Int).Value = invoice.CustomerID;
                _connection.Open();
                _cmd.ExecuteNonQuery();
            }
        }
    }
}
